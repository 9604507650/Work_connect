import tkinter as tk
from tkinter import messagebox, ttk
from config import initialize_database as init_db 
from auth import authenticate_user, create_user
from worker_dashboard import worker_dashboard
from customer_dashboard import customer_dashboard
from utils import load_image

class AnimatedBackground(tk.Canvas):
    def __init__(self, master, width, height):
        super().__init__(master, width=width, height=height, highlightthickness=0)
        self.width = width
        self.height = height
        
        # Create gradient animation
        self.colors = [(173, 216, 230), (135, 206, 250), (176, 224, 230), (240, 248, 255)]
        self.current_color = 0
        self.next_color = 1
        self.step = 0
        self.steps = 50
        
        self.animate()
    
    def interpolate_color(self, color1, color2, factor):
        return tuple(int(c1 + (c2 - c1) * factor) for c1, c2 in zip(color1, color2))
    
    def animate(self):
        if self.step >= self.steps:
            self.step = 0
            self.current_color = self.next_color
            self.next_color = (self.next_color + 1) % len(self.colors)
        
        factor = self.step / self.steps
        current = self.colors[self.current_color]
        next_c = self.colors[self.next_color]
        color = self.interpolate_color(current, next_c, factor)
        
        hex_color = f'#{color[0]:02x}{color[1]:02x}{color[2]:02x}'
        self.delete("all")
        self.create_rectangle(0, 0, self.width, self.height, fill=hex_color, outline=hex_color)
        
        self.step += 1
        self.after(100, self.animate)

class WorkerFinderApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🔧 WorkConnect - Find Professional Workers")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        # Initialize database
        init_db()
        
        # Store images to prevent garbage collection
        self.images = {}
        
        self.create_main_interface()
    
    def create_main_interface(self):
        # Animated background
        self.bg = AnimatedBackground(self.root, 900, 700)
        self.bg.pack(fill="both", expand=True)
        
        # Main container
        main_container = tk.Frame(self.bg, bg='white', bd=5, relief='ridge')
        main_container.place(relx=0.5, rely=0.5, anchor='center', width=750, height=600)
        
        # Header with logo
        header_frame = tk.Frame(main_container, bg='#2c3e50', height=100)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="🔧 WorkConnect", 
                font=("Arial", 28, "bold"), bg='#2c3e50', fg='white').pack(pady=25)
        tk.Label(header_frame, text="Connect with Trusted Professionals", 
                font=("Arial", 14), bg='#2c3e50', fg='#ecf0f1').pack()
        
        # Content frame
        content_frame = tk.Frame(main_container, bg='white')
        content_frame.pack(fill='both', expand=True, padx=30, pady=20)
        
        # Load and display main icon (using text as fallback)
        main_icon = load_image("https://img.icons8.com/fluency/96/tools.png", (80, 80))
        if main_icon:
            icon_label = tk.Label(content_frame, image=main_icon, bg='white')
            icon_label.image = main_icon  # Keep reference
            icon_label.pack(pady=10)
        else:
            # Fallback text icon
            tk.Label(content_frame, text="🔧", font=("Arial", 48), bg='white').pack(pady=10)
        
        # Login/Register form
        form_frame = tk.Frame(content_frame, bg='white')
        form_frame.pack(pady=20)
        
        # Username
        tk.Label(form_frame, text="Username:", font=("Arial", 12, "bold"), 
                bg='white', fg='#2c3e50').grid(row=0, column=0, sticky='w', pady=10)
        self.username_entry = tk.Entry(form_frame, font=("Arial", 12), width=25, bd=2, relief='groove')
        self.username_entry.grid(row=0, column=1, padx=10, pady=10)
        
        # Password
        tk.Label(form_frame, text="Password:", font=("Arial", 12, "bold"), 
                bg='white', fg='#2c3e50').grid(row=1, column=0, sticky='w', pady=10)
        self.password_entry = tk.Entry(form_frame, font=("Arial", 12), show="*", 
                                      width=25, bd=2, relief='groove')
        self.password_entry.grid(row=1, column=1, padx=10, pady=10)
        
        # Role selection with enhanced UI
        tk.Label(form_frame, text="I am a:", font=("Arial", 12, "bold"), 
                bg='white', fg='#2c3e50').grid(row=2, column=0, sticky='w', pady=20)
        
        role_frame = tk.Frame(form_frame, bg='white')
        role_frame.grid(row=2, column=1, padx=10, pady=20)
        
        self.role_var = tk.StringVar(value="customer")
        
        # Worker role button with image or text fallback
        worker_icon = load_image("https://img.icons8.com/fluency/48/worker-male.png", (40, 40))
        customer_icon = load_image("https://img.icons8.com/fluency/48/user-male.png", (40, 40))
        
        if worker_icon and customer_icon:
            # Use images if available
            self.worker_btn = tk.Radiobutton(role_frame, image=worker_icon, text=" Worker", 
                                            variable=self.role_var, value="worker",
                                            compound='left', font=("Arial", 11, "bold"),
                                            bg='white', selectcolor='#d5f5e3', 
                                            indicatoron=0, width=120, height=50)
            self.worker_btn.image = worker_icon
            self.worker_btn.grid(row=0, column=0, padx=10)
            
            self.customer_btn = tk.Radiobutton(role_frame, image=customer_icon, text=" Customer", 
                                              variable=self.role_var, value="customer",
                                              compound='left', font=("Arial", 11, "bold"),
                                              bg='white', selectcolor='#d6eaf8',
                                              indicatoron=0, width=120, height=50)
            self.customer_btn.image = customer_icon
            self.customer_btn.grid(row=0, column=1, padx=10)
            
            # Store images
            self.images['worker_icon'] = worker_icon
            self.images['customer_icon'] = customer_icon
        else:
            # Use text buttons as fallback
            self.worker_btn = tk.Radiobutton(role_frame, text="👷 Worker", 
                                            variable=self.role_var, value="worker",
                                            font=("Arial", 11, "bold"),
                                            bg='white', selectcolor='#d5f5e3', 
                                            indicatoron=0, width=15, height=2)
            self.worker_btn.grid(row=0, column=0, padx=10)
            
            self.customer_btn = tk.Radiobutton(role_frame, text="👤 Customer", 
                                              variable=self.role_var, value="customer",
                                              font=("Arial", 11, "bold"),
                                              bg='white', selectcolor='#d6eaf8',
                                              indicatoron=0, width=15, height=2)
            self.customer_btn.grid(row=0, column=1, padx=10)
        
        # Buttons
        btn_frame = tk.Frame(content_frame, bg='white')
        btn_frame.pack(pady=30)
        
        # Load button icons
        login_icon = load_image("https://img.icons8.com/fluency/48/login-rounded.png", (24, 24))
        register_icon = load_image("https://img.icons8.com/fluency/48/plus-math.png", (24, 24))
        
        if login_icon and register_icon:
            # Use image buttons if available
            self.images['login_icon'] = login_icon
            self.images['register_icon'] = register_icon
            
            login_btn = tk.Button(btn_frame, image=login_icon, text=" Login", compound='left',
                                 font=("Arial", 12, "bold"), bg='#27ae60', fg='white',
                                 command=self.login, padx=15, pady=8)
            login_btn.image = login_icon
            login_btn.grid(row=0, column=0, padx=15)
            
            register_btn = tk.Button(btn_frame, image=register_icon, text=" Register", compound='left',
                                   font=("Arial", 12, "bold"), bg='#3498db', fg='white',
                                   command=self.register, padx=15, pady=8)
            register_btn.image = register_icon
            register_btn.grid(row=0, column=1, padx=15)
        else:
            # Use text buttons as fallback
            tk.Button(btn_frame, text="🔐 Login", 
                     font=("Arial", 12, "bold"), bg='#27ae60', fg='white',
                     command=self.login, padx=15, pady=8).grid(row=0, column=0, padx=15)
            
            tk.Button(btn_frame, text="📝 Register", 
                     font=("Arial", 12, "bold"), bg='#3498db', fg='white',
                     command=self.register, padx=15, pady=8).grid(row=0, column=1, padx=15)
        
        # Footer
        footer_frame = tk.Frame(content_frame, bg='white')
        footer_frame.pack(side='bottom', pady=10)
        
        tk.Label(footer_frame, text="Find trusted professionals for all your needs", 
                font=("Arial", 10), bg='white', fg='#7f8c8d').pack()
        
        # Bind Enter key to login
        self.root.bind('<Return>', lambda e: self.login())
        
        # Set focus to username field
        self.username_entry.focus()
    
    def login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        role = self.role_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password!")
            return
        
        user_id = authenticate_user(username, password, role)
        if user_id:
            self.root.withdraw()  # Hide login window
            
            if role == "worker":
                worker_dashboard(user_id)
            else:
                customer_dashboard(user_id)
            
            # Set up callback for when dashboard closes
            self.root.after(100, self.check_dashboard_closed)
        else:
            messagebox.showerror("Error", "Invalid username, password, or role!")
    
    def register(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        role = self.role_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter both username and password!")
            return
        
        if len(username) < 3:
            messagebox.showerror("Error", "Username must be at least 3 characters long!")
            return
        
        if len(password) < 4:
            messagebox.showerror("Error", "Password must be at least 4 characters long!")
            return
        
        user_id = create_user(username, password, role)
        if user_id:
            messagebox.showinfo("Success", "Registration successful! You can now login.")
            self.username_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Error", "Registration failed! Username may already exist.")
    
    def check_dashboard_closed(self):
        # Check if any dashboard window is still open
        children = self.root.winfo_children()
        dashboards_open = any(isinstance(child, tk.Toplevel) for child in children)
        
        if not dashboards_open:
            self.root.deiconify()  # Show login window again
        else:
            self.root.after(100, self.check_dashboard_closed)
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = WorkerFinderApp()
    app.run() 