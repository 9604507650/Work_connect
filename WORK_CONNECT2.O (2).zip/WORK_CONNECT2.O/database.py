import sqlite3

def create_new_database():
    conn = sqlite3.connect("workconnect.db")
    c = conn.cursor()

    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('customer', 'worker', 'admin')) NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        name TEXT,
        email TEXT,
        mobile TEXT,
        address TEXT,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    );

    CREATE TABLE IF NOT EXISTS workers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        name TEXT,
        category TEXT,
        address TEXT,
        mobile TEXT,
        email TEXT,
        experience INTEGER,
        charges REAL,
        available_time TEXT,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    );

    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        worker_id INTEGER NOT NULL,
        category TEXT,
        description TEXT,
        booking_date TEXT DEFAULT (datetime('now')),
        scheduled_date TEXT,
        status TEXT DEFAULT 'pending',
        FOREIGN KEY(customer_id) REFERENCES customers(user_id),
        FOREIGN KEY(worker_id) REFERENCES workers(user_id)
    );
    """)

    # Insert one test customer and one worker
    c.execute("INSERT INTO users (username, password, role) VALUES ('alice', '123', 'customer')")
    c.execute("INSERT INTO users (username, password, role) VALUES ('sakshi', '123', 'worker')")

    c.execute("INSERT INTO customers (user_id, name, email, mobile, address) VALUES (1, 'Alice', 'alice@gmail.com', '11111', 'Pune')")
    c.execute("INSERT INTO workers (user_id, name, category, address, mobile, email, experience, charges, available_time) VALUES (2, 'Sakshi', 'Electrician', 'Mumbai', '22222', 'sakshi@gmail.com', 3, 250, '9am - 6pm')")

    conn.commit()
    conn.close()
    print("✅ New database 'workconnect.db' created successfully!")

if __name__ == "__main__":
    create_new_database()
