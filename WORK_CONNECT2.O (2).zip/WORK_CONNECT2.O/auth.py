# auth.py
from config import get_conn  # ✅ Replaced old import from database.py
from utils import hash_password, verify_password


def create_user(username, password, role):
    conn = get_conn()
    c = conn.cursor()
    try:
        # Hash password securely
        pwd_hash = hash_password(password)
        c.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, pwd_hash, role)
        )
        conn.commit()
        uid = c.lastrowid
        print(f"✅ User created successfully with ID: {uid}")

        # Create basic profile for the user
        if role == "customer":
            c.execute(
                "INSERT INTO customers (user_id, name) VALUES (?, ?)",
                (uid, username)
            )
        elif role == "worker":
            c.execute(
                "INSERT INTO workers (user_id, name) VALUES (?, ?)",
                (uid, username)
            )

        conn.commit()

    except Exception as e:
        print(f"❌ Error creating user: {e}")
        uid = None
    finally:
        conn.close()
    return uid


def authenticate_user(username, password, role):
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute(
            "SELECT user_id, password FROM users WHERE username=? AND role=?",
            (username, role)
        )
        row = c.fetchone()
        if row and verify_password(row[1], password):
            return row[0]
        return None
    except Exception as e:
        print(f"❌ Authentication error: {e}")
        return None
    finally:
        conn.close()


def get_user_profile(user_id, role):
    conn = get_conn()
    c = conn.cursor()
    try:
        if role == "worker":
            c.execute("""
                SELECT name, category, address, mobile, email, 
                       experience, charges, available_time
                FROM workers WHERE user_id=?
            """, (user_id,))
        else:
            c.execute("""
                SELECT name, address, mobile, email
                FROM customers WHERE user_id=?
            """, (user_id,))
        return c.fetchone()
    except Exception as e:
        print(f"❌ Error getting user profile: {e}")
        return None
    finally:
        conn.close()
