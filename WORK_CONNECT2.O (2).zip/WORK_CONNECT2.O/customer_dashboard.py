import tkinter as tk
from tkinter import ttk, messagebox
from config import get_conn, CATEGORIES
import datetime


class customer_dashboard:
    def __init__(self, user_id):
        self.user_id = user_id
        self.window = tk.Toplevel()
        self.window.title("Find Professional Workers")
        self.window.geometry("950x650")
        self.window.configure(bg='#f0f8ff')

        self.create_widgets()
        self.load_workers()
        self.check_notifications_periodically()

    def create_widgets(self):
        header = tk.Label(self.window, text="🔍 Find Professional Workers",
                          font=("Arial", 20, "bold"), bg="#34495e", fg="white", pady=10)
        header.pack(fill="x")

        filter_frame = tk.Frame(self.window, bg="#f0f8ff")
        filter_frame.pack(pady=10)

        tk.Label(filter_frame, text="Category:", font=("Arial", 12), bg="#f0f8ff").grid(row=0, column=0, padx=5)
        self.category_filter = ttk.Combobox(filter_frame, values=CATEGORIES, state="readonly", width=20)
        self.category_filter.grid(row=0, column=1, padx=5)

        tk.Button(filter_frame, text="🔄 Clear Filters", command=self.load_workers,
                  bg="#e74c3c", fg="white", font=("Arial", 10, "bold")).grid(row=0, column=2, padx=10)

        columns = ("ID", "Name", "Category", "Experience", "Charges", "Location", "Available")
        self.tree = ttk.Treeview(self.window, columns=columns, show="headings", height=15)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", width=120)
        self.tree.pack(fill="both", expand=True, padx=20, pady=10)

        btn_frame = tk.Frame(self.window, bg="#f0f8ff")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="✅ Book Selected Worker", command=self.book_worker,
                  bg="#27ae60", fg="white", font=("Arial", 12, "bold"), padx=10, pady=5).pack(side="left", padx=10)
        tk.Button(btn_frame, text="📋 My Bookings", command=self.view_bookings,
                  bg="#3498db", fg="white", font=("Arial", 12, "bold"), padx=10, pady=5).pack(side="left", padx=10)
        tk.Button(btn_frame, text="🚪 Logout", command=self.window.destroy,
                  bg="#e74c3c", fg="white", font=("Arial", 12, "bold"), padx=10, pady=5).pack(side="left", padx=10)

    def load_workers(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        conn = get_conn()
        c = conn.cursor()
        try:
            query = "SELECT user_id, name, category, experience, charges, address, available_time FROM workers"
            params = ()
            if self.category_filter.get():
                query += " WHERE category = ?"
                params = (self.category_filter.get(),)
            c.execute(query, params)
            for row in c.fetchall():
                self.tree.insert("", "end", values=row)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load workers: {e}")
        finally:
            conn.close()

    def book_worker(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a worker first!")
            return

        worker = self.tree.item(selected[0], "values")
        worker_id, name, category, exp, charges, loc, available = worker

        booking_win = tk.Toplevel(self.window)
        booking_win.title(f"Book {name}")
        booking_win.geometry("450x400")
        booking_win.configure(bg="#f0f8ff")

        tk.Label(booking_win, text=f"Book {name}", font=("Arial", 16, "bold"),
                 bg="#34495e", fg="white").pack(fill="x", pady=5)

        tk.Label(booking_win, text=f"Category: {category}\nCharges: ${charges}/hour",
                 font=("Arial", 11), bg="#f0f8ff").pack(pady=10)

        tk.Label(booking_win, text="Service Description:", font=("Arial", 11, "bold"),
                 bg="#f0f8ff").pack(anchor="w", padx=15)
        desc_box = tk.Text(booking_win, width=45, height=5)
        desc_box.pack(padx=15, pady=5)

        tk.Label(booking_win, text="Preferred Date (YYYY-MM-DD):", font=("Arial", 11, "bold"),
                 bg="#f0f8ff").pack(anchor="w", padx=15, pady=5)
        date_entry = tk.Entry(booking_win, width=20)
        date_entry.insert(0, str(datetime.date.today()))
        date_entry.pack(padx=15)

        def confirm_booking():
            description = desc_box.get("1.0", tk.END).strip()
            schedule_date = date_entry.get().strip()
            if not description:
                messagebox.showwarning("Warning", "Please enter a service description.")
                return
            if not schedule_date:
                messagebox.showwarning("Warning", "Please enter a preferred date.")
                return

            conn = get_conn()
            c = conn.cursor()
            try:
                # ✅ Ensure correct customer and worker IDs (linked via users.user_id)
                c.execute("SELECT user_id FROM customers WHERE user_id=?", (self.user_id,))
                cust_exists = c.fetchone()
                if not cust_exists:
                    messagebox.showerror("Error", "Customer profile not found.")
                    return

                c.execute("SELECT user_id FROM workers WHERE user_id=?", (worker_id,))
                work_exists = c.fetchone()
                if not work_exists:
                    messagebox.showerror("Error", "Worker profile not found.")
                    return

                c.execute("""
                    INSERT INTO bookings (customer_id, worker_id, category, description, scheduled_date, status)
                    VALUES (?, ?, ?, ?, ?, 'pending')
                """, (self.user_id, worker_id, category, description, schedule_date))
                conn.commit()
                messagebox.showinfo("Success", f"Booking sent to {name} successfully!")
                booking_win.destroy()
                self.show_notification(f"Booking request sent to {name}!")
            except Exception as e:
                messagebox.showerror("Error", f"Booking failed: {e}")
            finally:
                conn.close()

        btn_frame = tk.Frame(booking_win, bg="#f0f8ff")
        btn_frame.pack(pady=15)
        tk.Button(btn_frame, text="✅ Book Now", bg="#27ae60", fg="white", font=("Arial", 11, "bold"),
                  command=confirm_booking).pack(side="left", padx=10)
        tk.Button(btn_frame, text="❌ Cancel", bg="#e74c3c", fg="white", font=("Arial", 11, "bold"),
                  command=booking_win.destroy).pack(side="left", padx=10)

    # ✅ NEW: Notification system for customer
    def show_notification(self, message):
        """Show a notification to the customer"""
        notification = tk.Toplevel(self.window)
        notification.title("🔔 Notification")
        notification.geometry("300x100")
        notification.configure(bg='#d4edda')
        
        tk.Label(notification, text=message, font=("Arial", 11), 
                 bg='#d4edda', fg='#155724', wraplength=280).pack(expand=True, padx=10, pady=20)
        
        # Auto close after 3 seconds
        notification.after(3000, notification.destroy)

    # ✅ NEW: Periodic notification checking
    def check_notifications_periodically(self):
        """Check for notifications every 30 seconds"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT COUNT(*) 
                FROM bookings b 
                JOIN payments p ON b.id = p.booking_id 
                WHERE b.customer_id=? AND b.status='confirmed' AND p.status='pending'
            """, (self.user_id,))
            
            pending_payments = c.fetchone()[0]
            
            if pending_payments > 0:
                # Show a subtle notification
                if hasattr(self, 'notification_label'):
                    self.notification_label.config(text=f"🔔 {pending_payments} pending payment(s)")
                else:
                    # Create notification label if it doesn't exist
                    self.notification_label = tk.Label(self.window, text=f"🔔 {pending_payments} pending payment(s)", 
                                                     font=("Arial", 10, "bold"), bg="#f0f8ff", fg="#e74c3c")
                    self.notification_label.pack(pady=5)
                    
        except Exception as e:
            print(f"Notification check error: {e}")
        finally:
            conn.close()
        
        # Check again after 30 seconds
        self.window.after(30000, self.check_notifications_periodically)

    # ✅ NEW: Check notifications manually
    def check_notifications(self):
        """Check for new notifications (confirmed bookings ready for payment)"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT COUNT(*) 
                FROM bookings b 
                JOIN payments p ON b.id = p.booking_id 
                WHERE b.customer_id=? AND b.status='confirmed' AND p.status='pending'
            """, (self.user_id,))
            
            pending_payments = c.fetchone()[0]
            
            if pending_payments > 0:
                self.show_notification(f"You have {pending_payments} confirmed booking(s) ready for payment!")
            else:
                messagebox.showinfo("Notifications", "No new notifications.")
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to check notifications: {e}")
        finally:
            conn.close()

    # ✅ UPDATED: View Bookings with payment integration
    def view_bookings(self):
        booking_win = tk.Toplevel(self.window)
        booking_win.title("My Bookings")
        booking_win.geometry("1000x500")
        booking_win.configure(bg='#f0f8ff')

        tk.Label(booking_win, text="📋 My Bookings", font=("Arial", 18, "bold"),
                 bg="#34495e", fg="white").pack(fill="x", pady=10)

        # Add columns for payment status and actions
        columns = ("ID", "Worker", "Category", "Description", "Status", "Scheduled Date", "Amount", "Payment", "Action")
        tree = ttk.Treeview(booking_win, columns=columns, show="headings", height=15)
        
        for col in columns:
            tree.heading(col, text=col)
            if col in ["ID", "Amount"]:
                tree.column(col, width=80, anchor="center")
            else:
                tree.column(col, width=120, anchor="center")
        
        tree.pack(fill="both", expand=True, padx=20, pady=10)

        def load_bookings():
            for row in tree.get_children():
                tree.delete(row)
                
            conn = get_conn()
            c = conn.cursor()
            try:
                c.execute("""
                    SELECT b.id, w.name, b.category, b.description, b.status, 
                           b.scheduled_date, p.amount, p.status
                    FROM bookings b
                    JOIN workers w ON b.worker_id = w.user_id
                    LEFT JOIN payments p ON b.id = p.booking_id
                    WHERE b.customer_id=?
                    ORDER BY b.id DESC
                """, (self.user_id,))
                
                for row in c.fetchall():
                    booking_id, worker, category, desc, status, sched_date, amount, payment_status = row
                    
                    # Determine action button text and state
                    action = ""
                    if status == "confirmed" and payment_status == "pending":
                        action = "Pay Now"
                    elif status == "pending":
                        action = "Pending Worker"
                    elif payment_status == "paid":
                        action = "Paid ✓"
                    elif status == "rejected":
                        action = "Rejected"
                    elif status == "completed":
                        action = "Completed"
                    
                    tree.insert("", "end", values=(
                        booking_id, worker, category, desc, status, 
                        sched_date, f"${amount if amount else '0'}", 
                        payment_status if payment_status else "N/A", action
                    ))
                    
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load bookings: {e}")
            finally:
                conn.close()

        def handle_payment():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Warning", "Please select a booking first!")
                return
                
            booking_data = tree.item(selected[0], "values")
            booking_id, worker, category, desc, status, sched_date, amount, payment_status, action = booking_data
            
            if action != "Pay Now":
                messagebox.showinfo("Info", "This booking is not ready for payment.")
                return
                
            # Process payment
            conn = get_conn()
            c = conn.cursor()
            try:
                c.execute("UPDATE payments SET status='paid', payment_date=datetime('now') WHERE booking_id=?", (booking_id,))
                c.execute("UPDATE bookings SET status='paid' WHERE id=?", (booking_id,))
                conn.commit()
                
                messagebox.showinfo("Success", f"✅ Payment of {amount} processed successfully!")
                load_bookings()
                self.show_notification(f"Payment confirmed for {worker}!")
                
            except Exception as e:
                messagebox.showerror("Error", f"Payment failed: {e}")
            finally:
                conn.close()

        # Button frame
        btn_frame = tk.Frame(booking_win, bg='#f0f8ff')
        btn_frame.pack(pady=10)
        
        tk.Button(btn_frame, text="🔄 Refresh", command=load_bookings,
                  bg="#3498db", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=5)
        
        tk.Button(btn_frame, text="💳 Pay Now", command=handle_payment,
                  bg="#27ae60", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=5)
        
        tk.Button(btn_frame, text="📧 Check Notifications", command=self.check_notifications,
                  bg="#f39c12", fg="white", font=("Arial", 10, "bold")).pack(side="left", padx=5)

        load_bookings()