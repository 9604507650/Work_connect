# utils.py
import hashlib
import os
import binascii

def hash_password(password: str):
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100000)
    return binascii.hexlify(salt).decode() + ":" + binascii.hexlify(dk).decode()

def verify_password(stored, provided):
    try:
        salt_hex, dk_hex = stored.split(":")
        salt = binascii.unhexlify(salt_hex)
        dk = hashlib.pbkdf2_hmac("sha256", provided.encode(), salt, 100000)
        return binascii.hexlify(dk).decode() == dk_hex
    except:
        return False

def load_image(url_or_path, size):
    try:
        from PIL import Image, ImageTk
        import requests
        from io import BytesIO
        
        if url_or_path.startswith('http'):
            # Download image from URL
            response = requests.get(url_or_path, timeout=10)
            response.raise_for_status()
            image_data = BytesIO(response.content)
            image = Image.open(image_data)
        else:
            # Load local image file
            image = Image.open(url_or_path)
        
        # Resize image
        image = image.resize(size, Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(image)
        
    except Exception as e:
        print(f"Error loading image {url_or_path}: {e}")
        # Return None if image loading fails
        return None