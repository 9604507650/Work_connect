# notification_service.py
import sqlite3
from config import get_conn
from datetime import datetime, timedelta

class NotificationService:
    @staticmethod
    def create_notification(user_id, user_role, title, message, notification_type="info", related_entity=None, related_id=None):
        """Create a new notification"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                INSERT INTO notifications 
                (user_id, user_role, title, message, notification_type, related_entity, related_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, user_role, title, message, notification_type, related_entity, related_id))
            conn.commit()
            return True
        except Exception as e:
            print(f"Error creating notification: {e}")
            return False
        finally:
            conn.close()

    @staticmethod
    def get_unread_notifications(user_id, user_role, limit=10):
        """Get unread notifications for a user"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT id, title, message, notification_type, created_at, related_entity, related_id
                FROM notifications 
                WHERE user_id=? AND user_role=? AND is_read=0
                ORDER BY created_at DESC
                LIMIT ?
            """, (user_id, user_role, limit))
            return c.fetchall()
        except Exception as e:
            print(f"Error fetching notifications: {e}")
            return []
        finally:
            conn.close()

    @staticmethod
    def mark_as_read(notification_id):
        """Mark a notification as read"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("UPDATE notifications SET is_read=1 WHERE id=?", (notification_id,))
            conn.commit()
            return True
        except Exception as e:
            print(f"Error marking notification as read: {e}")
            return False
        finally:
            conn.close()

    @staticmethod
    def mark_all_as_read(user_id, user_role):
        """Mark all notifications as read for a user"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("UPDATE notifications SET is_read=1 WHERE user_id=? AND user_role=?", (user_id, user_role))
            conn.commit()
            return True
        except Exception as e:
            print(f"Error marking all notifications as read: {e}")
            return False
        finally:
            conn.close()

    @staticmethod
    def get_notification_count(user_id, user_role):
        """Get count of unread notifications"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT COUNT(*) FROM notifications 
                WHERE user_id=? AND user_role=? AND is_read=0
            """, (user_id, user_role))
            return c.fetchone()[0]
        except Exception as e:
            print(f"Error getting notification count: {e}")
            return 0
        finally:
            conn.close()