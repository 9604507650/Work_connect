import tkinter as tk
from tkinter import ttk, messagebox
from config import get_conn, CATEGORIES

from utils import load_image


class WorkerDashboard:
    def __init__(self, user_id):
        self.user_id = user_id
        self.window = tk.Toplevel()
        self.window.title("Worker Dashboard - Professional Profile")
        self.window.geometry("900x700")
        self.window.configure(bg='#f0f8ff')
        
        self.create_widgets()
        self.load_existing_profile()
        self.check_requests_periodically()
        
    def create_widgets(self):
        # Header
        header_frame = tk.Frame(self.window, bg='#2c3e50', height=80)
        header_frame.pack(fill='x', padx=10, pady=10)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="👷 Worker Professional Profile", 
                font=("Arial", 20, "bold"), bg='#2c3e50', fg='white').pack(pady=20)
        
        # Main content frame
        main_frame = tk.Frame(self.window, bg='#f0f8ff')
        main_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        # Profile form
        form_frame = tk.LabelFrame(main_frame, text="Personal Information", 
                                  font=("Arial", 12, "bold"), bg='#f0f8ff', fg='#2c3e50')
        form_frame.pack(fill='x', pady=10)
        
        fields = [
            ("Name", "text", None),
            ("Category", "combo", CATEGORIES),
            ("Address", "text", None),
            ("Mobile", "text", None),
            ("Email", "text", None),
            ("Experience (years)", "number", None),
            ("Charges ($/hour)", "number", None),
            ("Available Time", "text", None)
        ]
        
        self.entries = {}
        for i, (label, field_type, options) in enumerate(fields):
            row = tk.Frame(form_frame, bg='#f0f8ff')
            row.pack(fill='x', padx=10, pady=8)
            
            tk.Label(row, text=label, font=("Arial", 10, "bold"), bg='#f0f8ff', width=20, anchor='w').pack(side='left')
            
            if field_type == "number":
                entry = tk.Entry(row, font=("Arial", 10), width=30, validate='key')
                entry['validatecommand'] = (entry.register(self.validate_number), '%P')
            elif field_type == "combo":
                entry = ttk.Combobox(row, values=options, state="readonly", width=27, font=("Arial", 10))
            else:
                entry = tk.Entry(row, font=("Arial", 10), width=30)
            
            entry.pack(side='left', fill='x', expand=True)
            self.entries[label] = entry
        
        # Buttons frame
        btn_frame = tk.Frame(main_frame, bg='#f0f8ff')
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="💾 Save Profile", 
                 font=("Arial", 12, "bold"), bg='#27ae60', fg='white',
                 command=self.save_profile, padx=15, pady=8).pack(side='left', padx=10)
        
        tk.Button(btn_frame, text="📋 View Bookings", 
                 font=("Arial", 12, "bold"), bg='#3498db', fg='white',
                 command=self.view_bookings, padx=15, pady=8).pack(side='left', padx=10)

        # ✅ View Requests button
        tk.Button(btn_frame, text="📥 View Requests", 
                 font=("Arial", 12, "bold"), bg='#f39c12', fg='white',
                 command=self.view_requests, padx=15, pady=8).pack(side='left', padx=10)
        
        tk.Button(btn_frame, text="🚪 Logout", 
                 font=("Arial", 12, "bold"), bg='#e74c3c', fg='white',
                 command=self.window.destroy, padx=15, pady=8).pack(side='left', padx=10)
    
    def validate_number(self, value):
        if value == "" or value.isdigit():
            return True
        return False
    
    def load_existing_profile(self):
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""SELECT name, category, address, mobile, email, 
                        experience, charges, available_time 
                        FROM workers WHERE user_id=?""", (self.user_id,))
            row = c.fetchone()
            if row:
                fields = ["Name", "Category", "Address", "Mobile", "Email", 
                         "Experience (years)", "Charges ($/hour)", "Available Time"]
                for field, value in zip(fields, row):
                    if value is not None:
                        if field == "Category" and hasattr(self.entries[field], 'set'):
                            self.entries[field].set(value)
                        else:
                            self.entries[field].delete(0, tk.END)
                            self.entries[field].insert(0, str(value))
        except Exception as e:
            print(f"Error loading profile: {e}")
        finally:
            conn.close()
    
    def save_profile(self):
        try:
            name = self.entries["Name"].get().strip()
            
            if hasattr(self.entries["Category"], 'get'):
                category = self.entries["Category"].get().strip()
            else:
                category = self.entries["Category"].get().strip()
            
            if not name or not category:
                messagebox.showerror("Error", "Name and Category are required!")
                return
            
            conn = get_conn()
            c = conn.cursor()
            
            c.execute("SELECT id FROM workers WHERE user_id=?", (self.user_id,))
            exists = c.fetchone()
            
            if exists:
                c.execute("""UPDATE workers SET name=?, category=?, address=?, mobile=?, 
                            email=?, experience=?, charges=?, available_time=? 
                            WHERE user_id=?""",
                         (name, category, 
                          self.entries["Address"].get().strip(),
                          self.entries["Mobile"].get().strip(),
                          self.entries["Email"].get().strip(),
                          int(self.entries["Experience (years)"].get() or 0),
                          float(self.entries["Charges ($/hour)"].get() or 0),
                          self.entries["Available Time"].get().strip(),
                          self.user_id))
            else:
                c.execute("""INSERT INTO workers 
                            (user_id, name, category, address, mobile, email, 
                             experience, charges, available_time) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                         (self.user_id, name, category,
                          self.entries["Address"].get().strip(),
                          self.entries["Mobile"].get().strip(),
                          self.entries["Email"].get().strip(),
                          int(self.entries["Experience (years)"].get() or 0),
                          float(self.entries["Charges ($/hour)"].get() or 0),
                          self.entries["Available Time"].get().strip()))
            
            conn.commit()
            messagebox.showinfo("Success", "✅ Profile saved successfully!")
            
        except ValueError:
            messagebox.showerror("Error", "Please enter valid numbers for experience and charges!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save profile: {e}")
        finally:
            conn.close()

    # ✅ NEW: Notification system for worker
    def show_notification(self, message):
        """Show a notification to the worker"""
        notification = tk.Toplevel(self.window)
        notification.title("🔔 Notification")
        notification.geometry("300x100")
        notification.configure(bg='#fff3cd')
        
        tk.Label(notification, text=message, font=("Arial", 11), 
                 bg='#fff3cd', fg='#856404', wraplength=280).pack(expand=True, padx=10, pady=20)
        
        # Auto close after 3 seconds
        notification.after(3000, notification.destroy)

    # ✅ NEW: Periodic request checking
    def check_requests_periodically(self):
        """Check for new requests every 30 seconds"""
        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT COUNT(*) 
                FROM bookings 
                WHERE worker_id=? AND status='pending'
            """, (self.user_id,))
            
            pending_requests = c.fetchone()[0]
            
            if pending_requests > 0:
                # Show a subtle notification
                if hasattr(self, 'notification_label'):
                    self.notification_label.config(text=f"📥 {pending_requests} pending request(s)")
                else:
                    # Create notification label if it doesn't exist
                    self.notification_label = tk.Label(self.window, text=f"📥 {pending_requests} pending request(s)", 
                                                     font=("Arial", 10, "bold"), bg="#f0f8ff", fg="#e74c3c")
                    self.notification_label.pack(pady=5)
                    
        except Exception as e:
            print(f"Notification check error: {e}")
        finally:
            conn.close()
        
        # Check again after 30 seconds
        self.window.after(30000, self.check_requests_periodically)

    # ✅ UPDATED: View Requests with payment integration
    def view_requests(self):
        req_window = tk.Toplevel(self.window)
        req_window.title("Customer Requests")
        req_window.geometry("900x500")
        req_window.configure(bg='#f0f8ff')

        header = tk.Frame(req_window, bg='#2c3e50', height=60)
        header.pack(fill='x', padx=10, pady=10)
        header.pack_propagate(False)
        tk.Label(header, text="📥 Pending Customer Requests",
                 font=("Arial", 18, "bold"), bg='#2c3e50', fg='white').pack(pady=15)

        frame = tk.Frame(req_window, bg='#f0f8ff')
        frame.pack(fill='both', expand=True, padx=20, pady=10)

        tree = ttk.Treeview(frame,
                            columns=("ID", "Customer", "Category", "Description", "Status", "Booking Date", "Scheduled Date"),
                            show="headings", height=15)

        for col in ("ID", "Customer", "Category", "Description", "Status", "Booking Date", "Scheduled Date"):
            tree.heading(col, text=col)
            tree.column(col, width=120)
        tree.pack(fill='both', expand=True, padx=10, pady=10)

        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')

        conn = get_conn()
        c = conn.cursor()
        try:
            c.execute("""
                SELECT b.id, c.name, b.category, b.description, b.status, b.booking_date, b.scheduled_date
                FROM bookings b
                JOIN customers c ON b.customer_id = c.user_id
                WHERE b.worker_id=? AND b.status='pending'
                ORDER BY b.booking_date DESC
            """, (self.user_id,))
            requests = c.fetchall()

            if requests:
                for r in requests:
                    tree.insert("", "end", values=r)
            else:
                tree.insert("", "end", values=("", "No pending requests", "", "", "", "", ""))

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load requests: {e}")
        finally:
            conn.close()

        def confirm_request():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("Info", "Select a request first.")
                return
            req_id = tree.item(selected[0], 'values')[0]
            if not req_id:
                return

            conn = get_conn()
            c = conn.cursor()
            try:
                # Get booking details to create payment record
                c.execute("SELECT worker_id, scheduled_date FROM bookings WHERE id=?", (req_id,))
                booking = c.fetchone()
                
                if booking:
                    worker_id, scheduled_date = booking
                    # Get worker charges
                    c.execute("SELECT charges FROM workers WHERE user_id=?", (worker_id,))
                    worker_charges = c.fetchone()
                    charges = worker_charges[0] if worker_charges else 0
                    
                    # Update booking status and create payment record
                    c.execute("UPDATE bookings SET status='confirmed' WHERE id=?", (req_id,))
                    c.execute("INSERT INTO payments (booking_id, amount, status) VALUES (?, ?, 'pending')", 
                             (req_id, charges))
                    conn.commit()
                    
                    messagebox.showinfo("Success", "✅ Request confirmed successfully! Customer has been notified.")
                    req_window.destroy()
                    self.show_notification(f"Booking #{req_id} confirmed!")
                else:
                    messagebox.showerror("Error", "Booking not found.")
                    
            except Exception as e:
                messagebox.showerror("Error", f"Failed to confirm: {e}")
            finally:
                conn.close()

        def reject_request():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("Info", "Select a request first.")
                return
            req_id = tree.item(selected[0], 'values')[0]
            if not req_id:
                return

            conn = get_conn()
            c = conn.cursor()
            try:
                c.execute("UPDATE bookings SET status='rejected' WHERE id=?", (req_id,))
                conn.commit()
                messagebox.showinfo("Success", "❌ Request rejected successfully!")
                req_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to reject: {e}")
            finally:
                conn.close()

        btn_frame = tk.Frame(req_window, bg='#f0f8ff')
        btn_frame.pack(pady=10)
        
        tk.Button(btn_frame, text="✅ Confirm Selected Request",
                  font=("Arial", 11, "bold"), bg='#27ae60', fg='white',
                  command=confirm_request, padx=15, pady=6).pack(side='left', padx=10)
                  
        tk.Button(btn_frame, text="❌ Reject Request",
                  font=("Arial", 11, "bold"), bg='#e74c3c', fg='white',
                  command=reject_request, padx=15, pady=6).pack(side='left', padx=10)
    
    def view_bookings(self):
        booking_window = tk.Toplevel(self.window)
        booking_window.title("My Bookings")
        booking_window.geometry("900x500")
        booking_window.configure(bg='#f0f8ff')
        
        header_frame = tk.Frame(booking_window, bg='#2c3e50', height=60)
        header_frame.pack(fill='x', padx=10, pady=10)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text="Your Bookings", 
                font=("Arial", 18, "bold"), bg='#2c3e50', fg='white').pack(pady=15)
        
        tree_frame = tk.Frame(booking_window, bg='#f0f8ff')
        tree_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        tree = ttk.Treeview(tree_frame, 
                           columns=("ID", "Customer", "Category", "Description", "Status", "Booking Date", "Scheduled Date"), 
                           show="headings", height=15)
        
        tree.column("ID", width=0, stretch=tk.NO)
        
        columns = {
            "Customer": 120,
            "Category": 100,
            "Description": 200,
            "Status": 80,
            "Booking Date": 120,
            "Scheduled Date": 120
        }
        
        for col, width in columns.items():
            tree.heading(col, text=col)
            tree.column(col, width=width)
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        action_frame = tk.Frame(booking_window, bg='#f0f8ff')
        action_frame.pack(pady=10)
        
        def update_booking_status(new_status):
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showinfo("Info", "Please select a booking first.")
                return
            
            booking_data = tree.item(selected_item[0], 'values')
            booking_id = booking_data[0]
            
            conn = get_conn()
            c = conn.cursor()
            try:
                c.execute("UPDATE bookings SET status=? WHERE id=?", (new_status, booking_id))
                conn.commit()
                messagebox.showinfo("Success", f"Booking status updated to '{new_status}'")
                view_bookings()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update status: {e}")
            finally:
                conn.close()
        
        tk.Button(action_frame, text="✅ Mark as Confirmed", 
                 font=("Arial", 10, "bold"), bg='#27ae60', fg='white',
                 command=lambda: update_booking_status('confirmed'), 
                 padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(action_frame, text="🔄 Mark as Completed", 
                 font=("Arial", 10, "bold"), bg='#3498db', fg='white',
                 command=lambda: update_booking_status('completed'), 
                 padx=10, pady=5).pack(side='left', padx=5)
        
        tk.Button(action_frame, text="❌ Mark as Cancelled", 
                 font=("Arial", 10, "bold"), bg='#e74c3c', fg='white',
                 command=lambda: update_booking_status('cancelled'), 
                 padx=10, pady=5).pack(side='left', padx=5)
        
        def view_bookings():
            for item in tree.get_children():
                tree.delete(item)
                
            conn = get_conn()
            c = conn.cursor()
            try:
                c.execute("""SELECT b.id, c.name, b.category, b.description, b.status, 
                                    b.booking_date, b.scheduled_date 
                            FROM bookings b 
                            JOIN customers c ON b.customer_id = c.user_id 
                            WHERE b.worker_id=?""", (self.user_id,))
                bookings = c.fetchall()
                
                for booking in bookings:
                    tree.insert("", "end", values=booking)
                    
                if not bookings:
                    tree.insert("", "end", values=("", "No bookings yet", "", "", "", "", ""))
                    
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load bookings: {e}")
            finally:
                conn.close()
        
        view_bookings()


def worker_dashboard(user_id):
    WorkerDashboard(user_id)