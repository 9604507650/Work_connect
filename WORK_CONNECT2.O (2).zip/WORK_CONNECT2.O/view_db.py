# view_db.py
import sqlite3
from config import DB_PATH

from database import MYSQL_CONFIG

def view_database():
    try:
        # Connect to database
        conn = sqlite3.connect(**MYSQL_CONFIG)
        c = conn.cursor()
        
        print("🔍 WORKER FINDER MYSQL DATABASE CONTENTS")
        print("=" * 60)
        
        # List of tables to view
        tables = ['users', 'workers', 'customers', 'bookings']
        
        for table in tables:
            print(f"\n📊 TABLE: {table.upper()}")
            print("-" * 40)
            
            try:
                # Get all data from table
                c.execute(f"SELECT * FROM {table}")
                rows = c.fetchall()
                
                if rows:
                    # Get column names
                    c.execute(f"DESCRIBE {table}")
                    columns = [col[0] for col in c.fetchall()]
                    print(" | ".join(columns))
                    print("-" * 40)
                    
                    for row in rows:
                        print(" | ".join(str(item) for item in row))
                else:
                    print("No data found")
                    
            except Exception as e:
                print(f"Error reading table: {e}")
        
        conn.close()
        print("\n" + "=" * 60)
        print("MySQL database viewing complete!")
        
    except Exception as e:
        print(f"Error connecting to database: {e}")

if __name__ == "__main__":
    view_database()