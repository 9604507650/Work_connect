# config.py
import sqlite3
import os

# Database file path
DB_PATH = os.path.join(os.path.dirname(__file__), "workconnect.db")

# Worker categories for dropdown menus
CATEGORIES = [
    "Electrician",
    "Plumber",
    "Carpenter",    
    "Painter",
    "Mechanic",
    "Cleaner",
    "Gardener",
    "Technician"
]

def get_conn():
    """Get a SQLite database connection with foreign key support."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")  # ✅ Enable foreign key constraint checks
    return conn


def initialize_database():
    """Create all required tables if they don't exist."""
    conn = get_conn()
    c = conn.cursor()

    # ✅ Users table (base login info)
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT CHECK(role IN ('customer', 'worker', 'admin')) NOT NULL
        )
    """)

    # ✅ Workers table
    c.execute("""
        CREATE TABLE IF NOT EXISTS workers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            name TEXT,
            category TEXT,
            address TEXT,
            mobile TEXT,
            email TEXT,
            experience INTEGER,
            charges REAL,
            available_time TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    """)

    # ✅ Customers table
    c.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            name TEXT,
            address TEXT,
            mobile TEXT,
            email TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    """)

    # ✅ Bookings table
    c.execute("""
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            worker_id INTEGER,
            category TEXT,
            description TEXT,
            booking_date TEXT DEFAULT (DATE('now')),
            scheduled_date TEXT,
            status TEXT DEFAULT 'pending',
            FOREIGN KEY (customer_id) REFERENCES customers(user_id) ON DELETE CASCADE,
            FOREIGN KEY (worker_id) REFERENCES workers(user_id) ON DELETE CASCADE
        )
    """)

    # ✅ Payments table (NEW)
    c.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER UNIQUE,
            amount REAL,
            status TEXT DEFAULT 'pending',
            payment_date TEXT,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            user_role TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            notification_type TEXT DEFAULT 'info',
            is_read BOOLEAN DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now')),
            related_entity TEXT,
            related_id INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Database initialized successfully!")
    print(f"📁 Database ready at: {DB_PATH}")


# Initialize database on first run
if __name__ == "__main__":
    initialize_database()